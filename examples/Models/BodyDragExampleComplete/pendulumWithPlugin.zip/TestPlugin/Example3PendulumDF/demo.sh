opensim-cmd -L  libBodyDragForce.so run-tool pendulumDFFT.xml 

